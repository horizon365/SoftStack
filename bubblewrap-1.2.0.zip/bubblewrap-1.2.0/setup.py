from distutils.core import setup
setup(name= 'bubblewrap',version= '1.2.0',py_modules= ['bubblewrap'])
